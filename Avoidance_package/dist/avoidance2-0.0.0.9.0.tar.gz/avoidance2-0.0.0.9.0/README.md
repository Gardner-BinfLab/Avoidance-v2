# Avoidance2 

This includes all core algorithms and features required to sample and optimize 
RNAs.
